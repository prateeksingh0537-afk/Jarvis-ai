const btn = document.querySelector('.talk');
const content = document.querySelector('.content');

function speak(text) {
    const utterance = new SpeechSynthesisUtterance(text);
    utterance.rate = 1;
    utterance.pitch = 1;
    utterance.volume = 1;
    window.speechSynthesis.speak(utterance);
}

function wishMe() {
    const hour = new Date().getHours();
    if (hour >= 0 && hour < 12) {
        speak("Good Morning Boss");
    } else if (hour === 12) {
        speak("Good Noon Boss");
    } else if (hour > 12 && hour <= 17) {
        speak("Good Afternoon Boss");
    } else {
        speak("Good Evening Boss");
    }
}

window.addEventListener('load', () => {
    speak("Activating JARVIS");
    speak("Going online");
    wishMe();
});

const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
const recognition = new SpeechRecognition();
recognition.continuous = false;
recognition.interimResults = false;
recognition.lang = 'en-US';

recognition.onresult = (event) => {
    const transcript = event.results[0][0].transcript.trim();
    content.textContent = transcript;
    speakThis(transcript.toLowerCase());
};

btn.addEventListener('click', () => {
    content.textContent = "Listening...";
    recognition.start();
});

const openTabs = {};

function speakThis(message) {
    let response = "I did not understand what you said, please try again.";

    const commands = [
        {
            keywords: ['hey', 'hello'],
            action: () => response = "Hello Boss"
        },
        {
            keywords: ['how are you?'],
            action: () => response = "I am fine boss, tell me how can I help you"
        },
        {
            keywords: ['what is your name?'],
            action: () => response = "My name is JARVIS"
        },
        {
            keywords: ['open google'],
            action: () => {
                openTabs.google = window.open("https://google.com", "google");
                response = "Opening Google";
            }
        },
        {
            keywords: ['close google'],
            action: () => {
                const tab = window.open('', 'google');
                if (tab) tab.close();
                response = "Closing Google";
            }
        },
        {
            keywords: ['open instagram'],
            action: () => {
                openTabs.instagram = window.open("https://instagram.com", "instagram");
                response = "Opening Instagram";
            }
        },
        {
            keywords: ['close instagram'],
            action: () => {
                const tab = window.open('', 'instagram');
                if (tab) tab.close();
                response = "Closing Instagram";
            }
        },
        {
            keywords: ['open youtube'],
            action: () => {
                openTabs.youtube = window.open("https://www.youtube.com", "youtube");
                response = "Opening YouTube";
            }
        },
        {
            keywords: ['close youtube'],
            action: () => {
                const tab = window.open('', 'youtube');
                if (tab) tab.close();
                response = "Closing YouTube";
            }
        },
        {
            keywords: ['open whatsapp'],
            action: () => {
                openTabs.whatsapp = window.open("https://web.whatsapp.com", "whatsapp");
                response = "Opening WhatsApp Web";
            }
        },
        {
            keywords: ['close whatsapp'],
            action: () => {
                const tab = window.open('', 'whatsapp');
                if (tab) tab.close();
                response = "Closing WhatsApp";
            }
        },
        {
            keywords: ['open telegram'],
            action: () => {
                openTabs.telegram = window.open("https://web.telegram.org", "telegram");
                response = "Opening Telegram Web";
            }
        },
        {
            keywords: ['close telegram'],
            action: () => {
                const tab = window.open('', 'telegram');
                if (tab) tab.close();
                response = "Closing Telegram";
            }
        },
        {
            keywords: ['search youtube'],
            action: () => {
                const query = message.toLowerCase().split("search youtube")[1].trim();
                if (query) {
                    window.open(`https://www.youtube.com/results?search_query=${encodeURIComponent(query)}`, "_blank");
                    response = `Here is what I found on YouTube for ${query}`;
                } else {
                    response = "Please say something to search on YouTube.";
                }
            }
        },
        {
            keywords: ['play song'],
            action: () => {
                const songQuery = message.toLowerCase().split("play song")[1]?.trim();
                if (songQuery) {
                    const url = `https://www.youtube.com/results?search_query=${encodeURIComponent(songQuery)}`;
                    window.open(url, "_blank");
                    response = `Searching and playing ${songQuery} song on YouTube.`;
                } else {
                    response = "Please say the song name to play on YouTube.";
                }
            }
        },
        {
            keywords: ['what is', 'who is', 'what are'],
            action: () => {
                window.open(`https://www.google.com/search?q=${encodeURIComponent(message)}`, "_blank");
                response = `This is what I found on the internet regarding ${message}`;
            }
        },
        {
            keywords: ['wikipedia'],
            action: () => {
                const query = message.replace("wikipedia", "").trim();
                window.open(`https://en.wikipedia.org/wiki/${encodeURIComponent(query)}`, "_blank");
                response = `This is what I found on Wikipedia about ${query}`;
            }
        },
        {
            keywords: ['time'],
            action: () => {
                const time = new Date().toLocaleTimeString();
                response = `The current time is ${time}`;
            }
        },
        {
            keywords: ['date'],
            action: () => {
                const date = new Date().toLocaleDateString();
                response = `Today's date is ${date}`;
            }
        },
        {
            keywords: ['open calculator'],
            action: () => {
                window.open("https://www.google.com/search?q=calculator", "_blank");
                response = "Opening Calculator";
            }
        }
    ];

    let matched = false;
    for (const cmd of commands) {
        if (cmd.keywords.some(kw => message.includes(kw))) {
            cmd.action();
            matched = true;
            break;
        }
    }

    if (!matched) {
        window.open(`https://www.google.com/search?q=${encodeURIComponent(message)}`, "_blank");
        response = `Here is what I found on Google for ${message}`;
    }

    speak(response);
}
